/**
 * Array Heap implimentation of a priority queue
 * @author Lachlan Plant
 */
/* Peter Huang
 * 300021511
 */

public class HeapPriorityQueue <K extends Comparable, V> implements PriorityQueue <K, V> {
//since the elements will be stored in min and max heaps, storage is no longer needed and replaced
	private Entry<K,V> buffer;
	private Entry<K,V> [] minHeap;
	private int minHeapTail;
	private Entry<K,V> [] maxHeap;
	private int maxHeapTail;
	/**
	 * Default constructor
	 */
	public HeapPriorityQueue() {
		this(100);
	}


	/**
	 * HeapPriorityQueue constructor with max storage of size elements
	 */
	public HeapPriorityQueue( int size ) {
		//initialize the heaps
		minHeap = new Entry [ size ];
		minHeapTail =-1;
		maxHeap = new Entry [ size ];
		maxHeapTail = -1;

		
	}


	/****************************************************
	*
	*             Priority Queue Methods
	*
	****************************************************/

	/**
	 * Returns the number of items in the priority queue.
	 * O(1)
	 * @return number of items
	 */
	public int size() {
		//since there are two tails now, the size is the sum of both. Originally size was tail + 1, but because there are two tails we add 2
		return 2+minHeapTail+maxHeapTail;
	} /* size */


	/**
	 * Tests whether the priority queue is empty.
	 * O(1)
	 * @return true if the priority queue is empty, false otherwise
	 */
	public boolean isEmpty() {
		//since there are two tails now, both of them has to be <0 instead of just one tail being <0
		return minHeapTail<0 && maxHeapTail<0;
	} /* isEmpty */


	/**
	 * Inserts a key-value pair and returns the entry created.
	 * O(log(n))
	 * @param key     the key of the new entry
	 * @param value   the associated value of the new entry
	 * @param ref     a reference to the associated entry in the the heap
	 * @return the entry storing the new key-value pair
	 * @throws IllegalArgumentException if the heap is full
	 */
	public Entry <K, V>insert( K key, V value) throws IllegalArgumentException {
		Entry <K,V> returnnode = new Entry <K,V> (null,null);
		if( minHeapTail==minHeap.length||maxHeapTail==maxHeap.length ) {
			throw new IllegalArgumentException ( "Heap Overflow" );
		}
		Entry <K, V>    e = new Entry <> ( key, value );//inserted node that will be returned
		//Step 1: check if buffer is empty. if not, then add the new node
		if(buffer == null){
			buffer = e;
		}
		//step 2: if buffer not empty:
		else {
			//check if the value of the buffer key is bigger or less than the element key
			int compareTest = buffer.key.compareTo(e.key);
//the new element and the element in the buffer form a new pair of element associated to each other
			buffer.setAssociate(e);
			e.setAssociate(buffer);
			if(compareTest<0){
				// if the buffer key is less than the element key, than the element will be the last node of the max heap and the buffer will be the last node of the min heap
				// first the tails of both heap must increase
				minHeapTail++;
				maxHeapTail++;
				//set the inserted node and the buffer node to the last nodes of max and min heaps respectively
				maxHeap[maxHeapTail]= e;
				minHeap[minHeapTail]= buffer;
				//set the indexes of the inserted node and the buffer node to the last nodes of max and min heaps respectively
				buffer.setIndex(minHeapTail);
				e.setIndex(maxHeapTail);
				// fix the heaps and reset the buffer 
				upHeapMin(minHeapTail);
				upHeapMax(maxHeapTail);
				buffer = null;
			}
			else if(compareTest>0) {
				// if the buffer key is greater than the element key, than the element will be the last node of the min heap and the buffer will be the last node of the max heap
				// first the tails of both heap must increase
				minHeapTail++;
				maxHeapTail++;
				//set the inserted node and the buffer node to the last nodes of min and max heaps respectively
				minHeap[minHeapTail]= e;
				maxHeap[maxHeapTail]= buffer;
				//set the indexes of the inserted node and the buffer node to the last nodes of max and min heaps respectively
				e.setIndex(minHeapTail);
				buffer.setIndex(maxHeapTail);
				// fix the heaps and reset the buffer 
				upHeapMin(minHeapTail);
				upHeapMax(maxHeapTail);
				buffer = null;
			}
		}
		//return the node
		return e;
		
	} /* insert */


	/**
	 * Returns (but does not remove) an entry with minimal key.
	 * O(1)
	 * @return entry having a minimal key (or null if empty)
	 */
	public Entry <K, V> min() {
		if( isEmpty() ) {
			return null;
		}
		//compare the buffer key to the smallest minheap key, if the buffer key is smaller returned the element stored in the buffer otherwise return the minheap element
		else if(buffer.key.compareTo(minHeap[0].key)<0){
			return buffer;
		}
		else {
			return minHeap[0];
		}
	} /* min */


	/**
	 * Removes and returns an entry with minimal key.
	 * O(log(n))
	 * @return the removed entry (or null if empty)
	 */
	public Entry <K, V> removeMin() {
		if( isEmpty() )
			return null;
//removing the minimum element in this case means removing the root of the min heap
		Entry <K,V> minHeapRoot = minHeap[0];
		//since we are involving the root node, we need to involve the node associated with the root
		Entry <K,V> rootAssociate = minHeap[0].getAssociate();
		//min root that will be returned
		Entry <K,V> min = new Entry <K,V> (null,null);
//check if buffer is empty
		if(buffer == null){
			// remove the associated element from the max-heap and insert it in the buffer
			buffer = rootAssociate;
			// set the minimum as the root
			min = minHeapRoot;
			//fix the min heap
			swapMinHeap(0,minHeapTail);
			downHeapMin(0);
		
			minHeap[minHeapTail]= null;
			minHeapTail--;
		}
		//if buffer isnt empty
		if(buffer != null){
			//check if the buffer element is greater than the root of the min heap
			int compareTest = buffer.key.compareTo(minHeapRoot.key);
			int compareMax= buffer.key.compareTo(rootAssociate.key);
			rootAssociate.setAssociate(buffer);
			buffer.setAssociate(rootAssociate);
			if(compareTest<0) {
				// if buffer key is smaller than root, return the buffer
				min=buffer;
				//the buffer and the associate root must form a pair
				if(compareMax<0) {
					//if buffer key is smaller than associated insert the buffer into the minheap
					minHeapTail++;
					minHeap[minHeapTail]=buffer;
					upHeapMin(minHeapTail);
					buffer=null;
				} 
				else if(compareMax>0) {
						//if buffer key is greater, then two elements must exchange values
					Entry <K,V> temp = buffer;
					buffer=rootAssociate;
					rootAssociate=temp;
					upHeapMax(rootAssociate.getIndex());
					downHeapMax(rootAssociate.getIndex());
					//the new buffer is now inserted into the minheap
					minHeapTail++;
					minHeap[minHeapTail]=buffer;
					upHeapMin(minHeapTail);
					buffer=null;
				}
				
			}
			else if(compareTest>0) {
				min= minHeapRoot;
				if(compareMax<0) {
					//if buffer key is smaller than associated insert the buffer into the minheap
					minHeapTail++;
					minHeap[minHeapTail]=buffer;
					upHeapMin(minHeapTail);
					buffer=null;
				} 
				else if(compareMax>0) {
						//if buffer key is greater, then two elements must exchange values
					Entry <K,V> temp = buffer;
					buffer=rootAssociate;
					rootAssociate=temp;
					upHeapMax(rootAssociate.getIndex());
					downHeapMax(rootAssociate.getIndex());
					//the new buffer is now inserted into the minheap
					minHeapTail++;
					minHeap[minHeapTail]=buffer;
					upHeapMin(minHeapTail);
					buffer=null;
				}
			}
		}
		return min;
	} /* removeMin */
	
public Entry <K, V> removeMax() {
		if( isEmpty() )
			return null;
//removing the max element in this case means removing the root of the max heap
		Entry <K,V> maxHeapRoot = maxHeap[0];
		//since we are involving the root node, we need to involve the node associated with the root
		Entry <K,V> rootAssociate = maxHeap[0].getAssociate();
		//max root that will be returned
		Entry <K,V> max = new Entry <K,V> (null,null);
//check if buffer is empty
		if(buffer == null){
			// remove the associated element from the max-heap and insert it in the buffer
			buffer = rootAssociate;
			// set the max as the root
			max = maxHeapRoot;
			//fix the max heap
			swapMaxHeap(0,maxHeapTail);
			downHeapMax(0);
		
			maxHeap[maxHeapTail]= null;
			maxHeapTail--;
		}
		//if buffer isnt empty
		if(buffer != null){
			//check if the buffer element is greater than the root of the min heap
			int compareTest = buffer.key.compareTo(maxHeapRoot.key);
			int compareMax= buffer.key.compareTo(rootAssociate.key);
			rootAssociate.setAssociate(buffer);
			buffer.setAssociate(rootAssociate);
			if(compareTest>0) {
				// if buffer key is bigger than root, return the buffer
				max=buffer;
				//the buffer and the associate root must form a pair
				if(compareMax>0) {
					//if buffer key is bigger than associate insert the buffer into the maxheap
					maxHeapTail++;
					maxHeap[maxHeapTail]=buffer;
					upHeapMax(maxHeapTail);
					buffer=null;
				} 
				else if(compareMax<0) {
						//if buffer key is smaller, then two elements must exchange values
					Entry <K,V> temp = buffer;
					buffer=rootAssociate;
					rootAssociate=temp;
					upHeapMin(rootAssociate.getIndex());
					downHeapMin(rootAssociate.getIndex());
					//the new buffer is now inserted into the maxheap
					maxHeapTail++;
					maxHeap[maxHeapTail]=buffer;
					upHeapMax(maxHeapTail);
					buffer=null;
				}
				
			}
			else if(compareTest<0) {
				max= maxHeapRoot;
				if(compareMax>0) {
					//if buffer key is bigger than associated insert the buffer into the maxheap
					maxHeapTail++;
					maxHeap[maxHeapTail]=buffer;
					upHeapMax(maxHeapTail);
					buffer=null;
				} 
				else if(compareMax<0) {
						//if buffer key is smaller, then two elements must exchange values
					Entry <K,V> temp = buffer;
					buffer=rootAssociate;
					rootAssociate=temp;
					upHeapMin(rootAssociate.getIndex());
					downHeapMin(rootAssociate.getIndex());
					//the new buffer is now inserted into the maxheap
					maxHeapTail++;
					maxHeap[maxHeapTail]=buffer;
					upHeapMax(maxHeapTail);
					buffer=null;
				}
				
			}
		}
		return max;
	} 
 /* removeMin */


	/****************************************************
	*
	*           Methods for Heap Operations
	*
	****************************************************/

	/**
	 * Algorithm to place element after insertion at the tail.
	 * O(log(n))
	 */
	private void upHeapMin( int location ) {
		if( location == 0 ) {
			return;
		}

		int    parent = parent ( location );

		if( minHeap [ parent ].key.compareTo ( minHeap [ location ].key ) > 0 ) {
			swapMinHeap ( location, parent );
			upHeapMin ( parent );
		}
	} /* upHeap for the minHeap*/
	
	private void upHeapMax( int location ) {
		if( location == 0 ) {
			return;
		}

		int    parent = parent ( location );

		if( maxHeap [ parent ].key.compareTo ( maxHeap [ location ].key ) < 0 ) {
			swapMaxHeap ( location, parent );
			upHeapMax ( parent );
		}
	} /* upHeap for the maxHeap*/


	/**
	 * Algorithm to place element after removal of root and tail element placed at root.
	 * O(log(n))
	 */
	private void downHeapMin( int location ) {
		int    left  = (location * 2) + 1;
		int    right = (location * 2) + 2;

		//Both children null or out of bound
		if( left > minHeapTail ) return;

		//left in right out;
		if( left == minHeapTail ) {
			if( minHeap [ location ].key.compareTo ( minHeap [ left ].key ) > 0 )
				swapMinHeap ( location, left );
			return;
		}

		int    toSwap = (minHeap [ left ].key.compareTo ( minHeap [ right ].key ) < 0) ?
		                left : right;

		if( minHeap [ location ].key.compareTo ( minHeap [ toSwap ].key ) > 0 ) {
			swapMinHeap ( location, toSwap );
			downHeapMin ( toSwap );
		}
	} /* downHeap for min heap*/
	
	private void downHeapMax( int location ) {
		int    left  = (location * 2) + 1;
		int    right = (location * 2) + 2;

		//Both children null or out of bound
		if( left > maxHeapTail ) return;

		//left in right out;
		if( left == maxHeapTail ) {
			if( maxHeap [ location ].key.compareTo ( maxHeap [ left ].key ) < 0 )
				swapMaxHeap ( location, left );
			return;
		}

		int    toSwap = (maxHeap [ left ].key.compareTo ( maxHeap [ right ].key ) < 0) ?
		                left : right;

		if( maxHeap [ location ].key.compareTo ( maxHeap [ toSwap ].key ) < 0 ) {
			swapMaxHeap ( location, toSwap );
			downHeapMax ( toSwap );
		}
	} /* downHeap for the max heap*/


	/**
	 * Find parent of a given location,
	 * Parent of the root is the root
	 * O(1)
	 */
	private int parent( int location ) {
		return (location - 1) / 2;
	} /* parent */


	/**
	 * Inplace swap of 2 elements, assumes locations are in array
	 * O(1)
	 */
	private void swapMinHeap( int location1, int location2 ) {
		Entry <K, V>    temp = minHeap [ location1 ];
		minHeap [ location1 ] = minHeap [ location2 ];
		minHeap [ location2 ] = temp;
		
		minHeap[location1].index= location1;
		minHeap[location2].index= location2;
	} /* swap for the minHeap*/
	
	private void swapMaxHeap( int location1, int location2 ) {
		Entry <K, V>    temp = maxHeap [ location1 ];
		maxHeap [ location1 ] = maxHeap [ location2 ];
		maxHeap [ location2 ] = temp;
		
		maxHeap[location1].index= location1;
		maxHeap[location2].index= location2;
	} /* swap for the maxHeap*/

    public void print() {
    	//first print whatever is stored in the buffer
		System.out.println(buffer);
		//space
		System.out.println();
		//print out the min heap elements
		for (int i = 0 ; i<minHeapTail+1;i++){
		  System.out.println ( "(" + minHeap[i].key.toString() + "," + minHeap[i].value.toString() + ":" + minHeap[i].index + "), " );
		}
		//space
		System.out.println();
		//print out the max heap elements
		for (int j = 0; j < maxHeapTail+1; j ++){
		  System.out.println ( "(" + maxHeap[j].key.toString() + "," + maxHeap[j].value.toString() + ":" + maxHeap[j].index + "), " );
		}
	}
}